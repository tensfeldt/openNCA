#' Mean residence time from the time of dosing to the last measurable concentration.
#'
#' @details
#' \strong{Single Dose Equation:}
#' \strong{For Model M1}
#' \enumerate{
#'  \tabular{rl}{
#'   \tab \figure{aumc_XpctP1.png} \cr
#'  }
#' }
#' \strong{Steady-State Equation:}
#' \strong{For Model M1}
#' \enumerate{
#'  \tabular{rl}{
#'   \tab \figure{aumc_XpctP1.png} \cr
#'  }
#' }
#' \eqn{AUMClast = Aea under the first moment curve from zero time until the last measurable concentration} \cr
#' \eqn{AUClast = Area under the concentration versus time curve from zero time until the time (Tlast) of the last measurable concentration (CLASTi} \cr
#' \eqn{DOF = duration of infusion, used for constant infusion models} \cr
#'
#' @param conc The concentration data (given in a vector form)
#' @param time The time data (given in a vector form)
#' @param method The method that will be used to calculate AUC (use either 1, 2, 3, or 4)\cr
#' \enumerate{
#' \item Linear-Log Trapezoidal Rule (default)
#' \item Linear Trapezoidal Rule
#' \item Log Trapezoidal Rule
#' \item Linear Up - Log Down Trapezoidal Rule
#' }
#' Note: check 'Methods' section below for more details \cr
#' @param model This is the model type
#' @param aucflag The auc exclude flag data (given in a numeric vector)
#' @param dof The duration of infusion (numeric value)
#' @param auclast The area under the concentration versus time curve from zero time until the time (TLAST) of the last measurable concentration (CLASTi) during the ith dosing interval (numeric value)
#' @param aumclast The area under the first moment curve from zero time until the time (TLAST) of the last measurable concentration (CLASTi) during the ith dosing interval (numeric value)
#' 
#' @section Returns:
#' \strong{Dataset} \cr
#' \itemize{
#'  \item SID: subject identification number
#'  \item AUMC_PER: percentage of area under the curve
#'  \item METHOD: method used to calculate AUC
#' }
#' 
#' @examples
#' #No appropriate examples
#'
#' @author
#' \itemize{
#'  \item \strong{Rudraya Technical Team}
#'  \item website: \url{www.rudraya.com}
#'  \item email: \url{support@rudraya.com}
#' }
#' @export
mrt_last <- function(conc = NULL, time = NULL, method = 1, model = "M1", aucflag = NULL, dof = NULL, auclast = NULL, aumclast = NULL){
  if(is.null(conc) && is.null(time)){
    stop("Error in mrt_last: 'conc' and 'time' vectors are NULL")
  } else if(is.null(conc)) {
    stop("Error in mrt_last: 'conc' vector is NULL")
  } else if(is.null(time)) {
    stop("Error in mrt_last: 'time' vectors is NULL")
  } else if(all(is.na(time))) { # 2019-09-11/TGT/
      return(NA)
  } else if(all(is.na(conc))) { # 2019-09-11/TGT/
      return(NA)
  }

  if(!(is.numeric(conc) && is.vector(conc)) ){
    stop("Error in mrt_last: 'conc' is not a numeric vector")
  }
  if(!(is.numeric(time) && is.vector(time)) ){
    stop("Error in mrt_last: 'time' is not a numeric vector")
  }
  if(length(time) != length(conc)){
    stop("Error in mrt_last: length of 'time' and 'conc' vectors are not equal")
  }
  if(method != 1 && method != 2 && method != 3 && method != 4){
    stop("Error in mrt_last: the value provided for 'method' is not correct")
  }
  if(model != "M1" && model != "m1" && model != "M2" && model != "m2" && model != "M3" && model != "m2"){
    stop("Error in mrt_last: the value provided for 'model' is not correct")
  }

  mrtlast <- NA
  if(model == "M1" || model == "m1" || model == "M2" || model == "m2" ) {
    if(is.null(auclast)){
      auclast <- auc_last(conc = conc, time = time, method = method, exflag = aucflag)
    }
    if(is.null(aumclast)){
      aumclast <- aumc_last(conc = conc, time = time, method = method, exflag = aucflag)
    }

    if(auclast <= 0 || aumclast < 0 || is.na(auclast) || is.na(aumclast)){
      mrtlast <- NA
    } else {
      mrtlast <- aumclast/auclast
    }
  } else if(model == "M3" || model == "m3") {
    if(is.null(dof)){
      stop("Error in mrt_last: dof is NULL")
    }
    if(!is.numeric(dof)){
      stop("Error in mrt_last: dof is not a numeric value")
    }

    if(is.null(auclast)){
      auclast <- auc_last(conc = conc, time = time, method = method, exflag = aucflag)
    }
    if(is.null(aumclast)){
      aumclast <- aumc_last(conc = conc, time = time, method = method, exflag = aucflag)
    }

    if(auclast <= 0 || aumclast < 0 || is.na(auclast) || is.na(aumclast)){
      mrtlast <- NA
    } else {
      mrtlast <- aumclast/auclast - dof/2
    }
  }

  return(mrtlast)
}
