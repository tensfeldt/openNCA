#' Helper Function for Estimating Missing Concentration Data for AUC Start and End Times
#' 
#' @param conc The concentration data (given in a vector form)
#' @param time The time data (given in a vector form)
#' @param interpolate The value to determine whether to interpolate data points (given in a logical form)
#' @param extrapolate The value to determine whether to extrapolate data points (given in a logical form)
#' @param auc_method The method specified for AUC (either 'LIN' or 'LOG')
#' @param model The model specification (either 'M1', 'M2', 'M3', or 'M4')
#' @param dosing_type The dosing type specification (either 'SD' or 'SS')
#' @param dosing_interval The current dosing interval (numeric value)
#' @param t_max The first time at which CMAXi is observed within the dosing interval (numeric value)
#' @param told The time of last dose (given in a numeric value)
#' @param prev_told The time of last dose from previous interval (given in a numeric value)
#' @param prev_tau The time duration of previous dosing interval (given in a numeric value)
#' @param last_crit_factor The criteria value for last time acceptance criteria (numeric value)
#' @param kel The KEL value (given as a numeric)
#' @param orig_conc The original (full) concentration data (given in a numeric vector)
#' @param orig_time The original (full) time data (given in a numeric vector)
#' @param orgtime The original time value from the map data ('nominal' or 'actual')
#' 
estimate_missing_concentration <- function(conc = NULL, time = NULL, interpolate = NULL, extrapolate = NULL, auc_method = NULL, model = NULL, dosing_type = NULL, dosing_interval = NULL, t_max = NULL, told = NULL, prev_told = NULL, prev_tau = NULL, last_crit_factor = NULL, kel = NULL, orig_conc = NULL, orig_time = NULL, orgtime = NULL) {
  if(is.null(auc_method)){
    stop("Error in estimate_missing_concentration: 'auc_method' is NULL")
  }
  if(auc_method != "LINLOG" && auc_method != "LIN" && auc_method != "LOG" && auc_method != "LINUP-LOGDOWN"){
    stop("Error in estimate_missing_concentration: 'auc_method' is not either 'LINLOG' or 'LIN' or 'LOG' or 'LINUP-LOGDOWN'")
  }
  
## 2019-11-24/RD Removing any CONC value that is equal to 0
  #FEEDBACK: Commented the code to account for interpolation between two 0 concentrations
  #sel_idx <- which(orig_conc == 0)
  #if(length(sel_idx) > 0){
  #  orig_conc <- orig_conc[-sel_idx]
  #  orig_time <- orig_time[-sel_idx] 
  #}
  tmp <- data.frame("CONC" = conc, "TIME" = time, "INT_EXT" = NA)

  for(i in 1:(nrow(tmp)-1)){
##    2019-11-08/RD Added for Interpolation for AUC Start time has no data
##        
    if(is.na(conc[1]) && i == 1){
      if(length(orig_time) > 0 && length(orig_conc) > 0){
        if(isTRUE(time[1] <= orig_time[1])){
          est_tmp <- estimate_told_concentration(conc = conc, time = time, interpolate = interpolate, extrapolate = extrapolate, auc_method = "LIN", model = model, dosing_type = dosing_type, dosing_interval = dosing_interval, told = told, prev_told = prev_told, prev_tau = prev_tau, last_crit_factor = last_crit_factor, orig_conc = orig_conc, orig_time = orig_time, orgtime = orgtime, tmp = tmp)
          conc <- est_tmp[[1]]
          tmp <- est_tmp[[2]]
        } else if(isTRUE((orig_time[1] < time[1]) && (time[1] < orig_time[length(orig_time)]))){
          if(isTRUE(interpolate)){
            idx <- which(orig_time < time[1])
            idx <- idx[length(idx)]
            if(length(idx) > 0){
              if(auc_method == "LINLOG"){
                if(!isTRUE(is.na(t_max) || is.null(t_max))){
                  if(isTRUE(time[1] < t_max)){
                    conc[1] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
                  } else {
                    #FEEDBACK: Added code to account for interpolation between two 0 concentrations
                    if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                      conc[1] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
                    } else {
                      conc[1] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
                    }
                  }
                } else {
                  conc[1] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
                }
              } else if(auc_method == "LIN"){
                conc[1] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
              } else if(auc_method == "LOG"){
                if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                  conc[1] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
                } else {
                  conc[1] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
                }
              } else if(auc_method == "LINUP-LOGDOWN"){
                if(isTRUE(orig_conc[idx] < orig_conc[idx+1])){
                  conc[1] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
                } else {
                  if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                    conc[1] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
                  } else {
                    conc[1] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[1])
                  }
                }
              }
              tmp$INT_EXT[1] <- "INT"
            }
          }
        } else if(isTRUE(time[1] >= orig_time[length(orig_time)])){
          if(!is.na(kel) && !is.null(kel)){
            if(!is.na(kel[["KEL"]])){
              if(isTRUE(extrapolate)){
                conc[1] <- cest(conc = conc, time = time, t_last = time[1], kel = kel[["KEL"]], kelc0 = kel[["KELC0"]])
                tmp$INT_EXT[1] <- "EXT"
              }
            } else {
              if(isTRUE(extrapolate)){
                conc[1] <- NA
                tmp$INT_EXT[1] <- "EXT"
              }
            }
          } else {
            if(isTRUE(extrapolate)){
              conc[1] <- NA
              tmp$INT_EXT[1] <- "EXT"
            }
          }
        }
      }
      if(isTRUE(is.na(conc[nrow(tmp)]) && (i+1) == nrow(tmp))){
        if(length(orig_time) > 0 && length(orig_conc) > 0){
          if(isTRUE((orig_time[1] < time[nrow(tmp)]) && (time[nrow(tmp)] < orig_time[length(orig_time)]))){
            if(isTRUE(interpolate)){
              idx <- which(orig_time < time[nrow(tmp)])
              idx <- idx[length(idx)]
              if(length(idx) > 0){
                if(auc_method == "LINLOG"){
                  if(!isTRUE(is.na(t_max) || is.null(t_max))){
                    if(isTRUE(time[1] < t_max)){
                      conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                    } else {
                      if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                        conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                      } else {
                        conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                      }
                    }
                  } else {
                    if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                      conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                    } else {
                      conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                    }
                  }
                } else if(auc_method == "LIN"){
                  conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                } else if(auc_method == "LOG"){
                  if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                    conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  } else {
                    conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  }
                } else if(auc_method == "LINUP-LOGDOWN"){
                  if(isTRUE(orig_conc[idx] < orig_conc[idx+1])){
                    conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  } else {
                    if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                      conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                    } else {
                      conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                    }
                  }
                }
                if(auc_method == "LIN"){
                  conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                } else if(auc_method == "LOG" || auc_method == "LINLOG"){
                  if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                    conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  } else {
                    conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  }
                }
                tmp$INT_EXT[nrow(tmp)] <- "INT"
              }
            }
          }
        }
      }
##    2019-11-08/RD Added for Interpolation for AUC End time has no data
##  
    } else if(isTRUE(is.na(conc[nrow(tmp)]) && (i+1) == nrow(tmp))){
      if(length(orig_time) > 0 && length(orig_conc) > 0){
        if(isTRUE((orig_time[1] < time[nrow(tmp)]) && (time[nrow(tmp)] < orig_time[length(orig_time)]))){
          if(isTRUE(interpolate)){
            idx <- which(orig_time < time[nrow(tmp)])
            idx <- idx[length(idx)]
            if(length(idx) > 0){
              if(auc_method == "LINLOG"){
                if(!isTRUE(is.na(t_max) || is.null(t_max))){
                  if(isTRUE(time[1] < t_max)){
                    conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  } else {
                    if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                      conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                    } else {
                      conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                    }
                  }
                } else {
                  if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                    conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  } else {
                    conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  }
                }
              } else if(auc_method == "LIN"){
                conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
              } else if(auc_method == "LOG"){
                if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                  conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                } else {
                  conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                }
              } else if(auc_method == "LINUP-LOGDOWN"){
                if(isTRUE(orig_conc[idx] < orig_conc[idx+1])){
                  conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                } else {
                  if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                    conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  } else {
                    conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                  }
                }
              }
              if(auc_method == "LIN"){
                conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
              } else if(auc_method == "LOG" || auc_method == "LINLOG"){
                if(isTRUE(orig_conc[idx] != 0 && orig_conc[idx+1] != 0)){
                  conc[nrow(tmp)] <- interpolate_log(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                } else {
                  conc[nrow(tmp)] <- interpolate_lin(conc1 = orig_conc[idx], time1 = orig_time[idx], conc2 = orig_conc[idx+1], time2 = orig_time[idx+1], est_time = time[nrow(tmp)])
                }
              }
              tmp$INT_EXT[nrow(tmp)] <- "INT"
            }
          }
        } else {
          if(!is.na(kel) && !is.null(kel)){
            if(!is.na(kel[["KEL"]])){
              if(isTRUE(extrapolate)){
                conc[nrow(tmp)] <- cest(conc = conc, time = time, t_last = time[length(time)], kel = kel[["KEL"]], kelc0 = kel[["KELC0"]])
                tmp$INT_EXT[nrow(tmp)] <- "EXT"
              }
            } else {
              if(isTRUE(extrapolate)){
                min_lim <- orig_time[length(orig_time)] - (orig_time[length(orig_time)] * 0.05)
                max_lim <- (orig_time[length(orig_time)] * 0.05) + orig_time[length(orig_time)]
                if(isTRUE(min_lim < time[nrow(tmp)] && time[nrow(tmp)] < max_lim)){
                  conc[nrow(tmp)] <- orig_conc[length(orig_conc)]
                  tmp$INT_EXT[nrow(tmp)] <- "EXT"
                } else {
                  conc[nrow(tmp)] <- NA
                  tmp$INT_EXT[nrow(tmp)] <- "EXT"
                }
              }
            }
          } else {
            if(isTRUE(extrapolate)){
              min_lim <- orig_time[length(orig_time)] - (orig_time[length(orig_time)] * 0.05)
              max_lim <- (orig_time[length(orig_time)] * 0.05) + orig_time[length(orig_time)]
              if(isTRUE(min_lim < time[nrow(tmp)] && time[nrow(tmp)] < max_lim)){
                conc[nrow(tmp)] <- orig_conc[length(orig_conc)]
                tmp$INT_EXT[nrow(tmp)] <- "EXT"
              } else {
                conc[nrow(tmp)] <- NA
                tmp$INT_EXT[nrow(tmp)] <- "EXT"
              }
            }
          }
        }
      }
    }
  }
  tmp$CONC <- conc
  return(list(conc, tmp))
}
