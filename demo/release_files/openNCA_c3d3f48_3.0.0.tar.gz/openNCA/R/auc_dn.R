#' Dose normalized area under the concentration versus time curve
#'
#' This function gets the dose normalized area under the concentration versus time curve from time 0
#' until the last time point.
#'
#' @details
#' \strong{Equation} \cr
#' \figure{auc_dn.png} \cr
#' \strong{Linear Method} \cr
#' \figure{auc_1.png} \cr
#' \strong{Log Method} \cr
#' \figure{auc_2.png} \cr
#' \eqn{AUC = Area under the cruve} \cr
#' \eqn{C_{i} = Concentration 1}{Ci = Concentration 1} \cr
#' \eqn{C_{i+1} = Concentration 2}{Ci+1 = Concentration 2} \cr
#' \eqn{T_{i} = Time 1}{Ti = Time 1} \cr
#' \eqn{T_{i+1} = Time 2}{Ti+1 = Time 2} \cr
#' \eqn{ln = Natural Logarithm} \cr \cr
#' \strong{Methods:} You can use the following methods to calculate AUC: \cr
#' \enumerate{
#'  \item \strong{Linear-Log Trapazoidal Rule}(default method): The linear method is used up to Tmax (the
#'  first occurrence of Cmax) and the log trapezoidal method is used for the remainder of the profile. If
#'  Ci or Ci+1 is 0 then the linear trapezoidal rule is used.
#'  \item \strong{Linear Trapazoidal Rule}: The linear method is used for the entire profile.
#'  \item \strong{Log Trapazoidal Rule}: The log trapezoidal method is used for the entire profile. If
#'  Ci or Ci+1 is 0 then the linear trapezoidal rule is used.
#'  \item \strong{Linear Up - Log Down Trapazoidal Rule}: Linear trapezoidal while the concentrations
#'  are increasing and log trapezoidal while the concentration are decreasing, the assessment is made on
#'  a step basis for each portion of the profile i.e. t1 to t2. If Ci or Ci+1 is 0 then the linear
#'  trapezoidal rule is used.
#' }
#' \strong{Equation} \cr
#' If the user selects the option to have dose normalized AUC then the following equation is applied: \cr
#' \figure{auc_dn.png} \cr
#'
#' @param auc The AUC data (given in a vector form)
#' @param dose The dose data (given in a vector form)
#'
#' @section Returns:
#' \strong{Value or Vector} \cr
#' \itemize{
#'  \item AUC: dose normalized area under the curve
#' }
#'
#' @examples
#'##########
#' ## Data ##
#' ######################################################
#' ##  SID  ##  TIME  ##   CONC   ##  EXFLAG  ##  DOSE ##
#' ######################################################
#' ##   30  ##    0   ##   2.89   ##    0     ##  200  ##
#' ##   30  ##    1   ##   2.49   ##    1     ##  200  ##
#' ##   30  ##    2   ##   2.47   ##    0     ##  200  ##
#' ##   30  ##    3   ##   2.38   ##    0     ##  200  ##
#' ##   30  ##    4   ##   2.32   ##    0     ##  200  ##
#' ##   30  ##    5   ##   2.28   ##    1     ##  200  ##
#' ######################################################
#'
#' #Data mentioned will be used for the following example
#'
#' #auc_dn()
#' #Error in auc_dn: 'auc' and 'dose' vectors are NULL
#'
#' conc_vector <- c(2.89, 2.49, 2.47, 2.38, 2.32, 2.28)
#' time_vector <- c(0, 1, 2, 3, 4, 5)
#' exflag_vector <- c(0, 1, 0, 0, 0, 1)
#'
#' auc_all(conc = conc_vector, time = time_vector, method = 1)
#' #12.23956
#'
#' auc_all(conc = conc_vector, time = time_vector, method = 1, exflag = exflag_vector)
#' #10.12361
#'
#' auc_dn(auc = 12.23956, dose = 200)
#' #0.0611978
#'
#' auc_dn(auc = 10.12361, dose = 200)
#' #0.05061805
#'
#' auc_dn(auc = c(12.23956, 10.12361), dose = c(200, 200))
#' #0.06119780 0.05061805
#'
#' auc_dn(auc = 10.12361, dose = NA)
#' #NA
#'
#' @author
#' \itemize{
#'  \item \strong{Thomas Tensfeldt, Pfizer & Rudraya Technical Team}
#'  \item website: \url{www.pfizer.com}
#'  \item email: \url{thomas.g.tensfeldt@pfizer.com}
#' }
#' @export
auc_dn <- function(auc = NULL, dose = NULL){
  if(is.null(auc) && is.null(dose)){
    stop("Error in auc_dn: 'auc' and 'dose' vectors are NULL")
  } else if(is.null(auc)) {
    stop("Error in auc_dn: 'auc' vector is NULL")
  } else if(is.null(dose)) {
    stop("Error in auc_dn: 'dose' vectors is NULL")
  } else if(all(is.na(dose))) { # 2019-10-01/TGT/
      return(NA)
  } else if(all(is.na(auc)))  { # 2019-10-01/TGT/
      return(NA)
  }

  if(length(dose) != length(auc) ){
    stop("Error in auc_dn: length of vector arguments do not match")
  }

  if(isTRUE(any(is.na(dose)) || (0 %in% dose) || any(is.na(auc)))) {
    aucdn <- NA
  } else {
    aucdn <- auc/dose
    aucdn <- replace(aucdn, is.infinite(aucdn), NA)
  }

  return(aucdn)
}
