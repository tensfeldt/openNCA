#' Percentage of AUMCINFO obtained by forward extrapolation
#'
#' Percentage of AUMCINFO obtained by forward extrapolation.\cr
#'
#' @details
#' \strong{Equation}
#' \enumerate{
#'  \tabular{rl}{
#'   \tab \figure{aumc_XpctO1.png} \cr
#'  }
#' }
#' @section Additional Details:
#' \strong{Linear Method} \cr
#' \figure{aumc_1.png} \cr
#' \strong{Log Method} \cr
#' \figure{aumc_2.png} \cr
#' \eqn{AUMC = Area under the first moment curve} \cr
#' \eqn{C_{i} = Concentration 1}{Ci = Concentration 1} \cr
#' \eqn{C_{i+1} = Concentration 2}{Ci+1 = Concentration 2} \cr
#' \eqn{T_{i} = Time 1}{Ti = Time 1} \cr
#' \eqn{T_{i+1} = Time 2}{Ti+1 = Time 2} \cr
#' \eqn{ln = Natural Logarithm} \cr \cr
#' \strong{Methods:} You can use the following methods to calculate AUC: \cr
#' \enumerate{
#'  \item \strong{Linear-Log Trapazoidal Rule}(default method): The linear method is used up to Tmax (the
#'  first occurance of Cmax) and the log trapezoidal method is used for the remainder of the profile. If
#'  Ci or Ci+1 is 0 then the linear trapezoidal rule is used.
#'  \item \strong{Linear Trapazoidal Rule}: The linear method is used for the entire profile.
#'  \item \strong{Log Trapazoidal Rule}: The log trapezoidal method is used for the entire profile. If
#'  Ci or Ci+1 is 0 then the linear trapezoidal rule is used.
#'  \item \strong{Linear Up - Log Down Trapazoidal Rule}: Linear trapezoidal while the concentrations
#'  are increasing and log trapezoidal while the concentration are decreasing, the assessment is made on
#'  a step basis for each portion of the profile i.e. t1 to t2. If Ci or Ci+1 is 0 then the linear
#'  trapezoidal rule is used.
#' }
#'
#' @section Note:
#' The inputs 'kelflag', 'aucflag' are optional. \cr
#' \strong{aumc_inf_o}: Refer to \code{\link{aumc_inf_o}} for more details
#' \strong{aumc_last}: Refer to \code{\link{aumc_last}} for more details
#'
#' @param conc The concentration data (given in a vector form)
#' @param time The time data (given in a vector form)
#' @param method The method that will be used to calculate AUC (use either 1, 2, 3, or 4)\cr
#' \enumerate{
#' \item Linear-Log Trapezoidal Rule (default)
#' \item Linear Trapezoidal Rule
#' \item Log Trapezoidal Rule
#' \item Linear Up - Log Down Trapezoidal Rule
#' }
#' Note: check 'Methods' section below for more details \cr
#' @param kelflag The KEL exclude flag data (given in a numeric vector)
#' @param aucflag The AUC exclude flag data (given in a numeric vector)
#' @param spanratio The SPAN Ratio (numeric value)
#' @param kel The terminal phase rate constant for the concentration-time profile of interest (numeric value)
#' @param aumcinfo The area under the first moment curve from time 0 to infinity (Observed) (numeric value)
#' @param aumclast The area under the first moment curve from the start of the dosing interval (TOLDi) until the last measurable concentration (CLASTi) during the ith dosing interval (numeric value)
#'
#' @section Returns:
#' \strong{Value} \cr
#' \itemize{
#'  \item AUMCXPCTO: percentage of AUMCINFO obtained
#' }
#'
#' @examples
#' ##########
#' ## Data ##
#' #################################
#' ##  SID  ##  TIME  ##   CONC   ##
#' #################################
#' ##   30  ##    0   ##   2.89   ##
#' ##   30  ##    1   ##   2.49   ##
#' ##   30  ##    2   ##   2.47   ##
#' ##   30  ##    3   ##   2.38   ##
#' ##   30  ##    4   ##   2.32   ##
#' ##   30  ##    5   ##   2.28   ##
#' #################################
#'
#' #Data mentioned will be used for the following example
#'
#' #aumc_XpctO()
#' #Error in aumc_XpctO: 'conc' and 'time' vectors are NULL
#'
#' conc_vector <- c(2.89, 2.49, 2.47, 2.38, 2.32, 2.28)
#' time_vector <- c(0, 1, 2, 3, 4, 5)
#'
#' aumc_XpctO(conc = conc_vector, time = time_vector)
#' #98.21905
#'
#' ############
#' ## Data 2 ##
#' #################################
#' ##  SID  ##  TIME  ##   CONC   ##
#' #################################
#' ##   31  ##    0   ##      0   ##
#' ##   31  ##    1   ##      0   ##
#' ##   31  ##    2   ##      0   ##
#' #################################
#'
#' #Data mentioned will be used for the following example
#'
#' conc_vector <- c(0, 0, 0)
#' time_vector <- c(0, 1, 2)
#'
#' aumc_XpctO(conc = conc_vector, time = time_vector)
#' #0
#'
#' @author
#' \itemize{
#'  \item \strong{Rudraya Technical Team}
#'  \item website: \url{www.rudraya.com}
#'  \item email: \url{support@rudraya.com}
#' }
#' @export
aumc_XpctO <- function(conc = NULL, time = NULL, method = 1, kelflag = NULL, aucflag = NULL, spanratio = NULL, kel = NULL, aumcinfo = NULL, aumclast = NULL){
  if(is.null(conc) && is.null(time)){
    stop("Error in aumc_XpctO: 'conc' and 'time' vectors are NULL")
  } else if(is.null(conc)) {
    stop("Error in aumc_XpctO: 'conc' vector is NULL")
  } else if(is.null(time)) {
    stop("Error in aumc_XpctO: 'time' vectors is NULL")
  } else if(all(is.na(time))) { # 2019-09-11/TGT/
      return(NA)
  } else if(all(is.na(conc))) { # 2019-09-11/TGT/
      return(NA)
  }

  if(!(is.numeric(conc) && is.vector(conc)) ){
    stop("Error in aumc_XpctO: 'conc' is not a numeric vector")
  }
  if(!(is.numeric(time) && is.vector(time)) ){
    stop("Error in aumc_XpctO: 'time' is not a numeric vector")
  }
  if(length(time) != length(conc)){
    stop("Error in aumc_XpctO: length of 'time' and 'conc' vectors are not equal")
  }
  if(method != 1 && method != 2 && method != 3 && method != 4){
    stop("Error in aumc_XpctO: the value provided for 'method' is not correct")
  }

  if(sum(conc, na.rm=T) == 0){
    aumc_xpcto <- NA
    return(aumc_xpcto)
  } else {
    if(is.null(aumcinfo)){
      aumcinfo <- aumc_inf_o(conc = conc, time = time, method = method, kelflag = kelflag, aucflag = aucflag, spanratio = spanratio, kel = kel)
    }
    if(is.null(aumclast)){
      aumclast <- aumc_last(conc = conc, time = time, method = method, exflag = aucflag)
    }
    
    if(is.na(aumcinfo) || aumcinfo == 0 || is.na(aumclast)){
      aumc_xpcto <- NA
      return(aumc_xpcto)
    } else {
      aumc_xpcto <- ((aumcinfo - aumclast)/aumcinfo)*100
      return(aumc_xpcto)
    }
  }
}
