#' Area under the concentration versus time curve from time 0 until the last time point
#'
#' This function gets the area under the concentration versus time curve from time 0 until the last
#' time point. As illustrated in the following figure, AUC_ALL includes the trapezoidal area from the
#' time of the last measurable concentration to the next time point. Although there may be additional
#' time points, there is no additional AUC since by definition all subsequent concentrations are zero.\cr
#' \figure{auc_all.png}
#'
#' @details
#' \strong{Linear Method} \cr
#' \figure{auc_1.png} \cr
#' \strong{Log Method} \cr
#' \figure{auc_2.png} \cr
#' \eqn{AUC = Area under the curve} \cr
#' \eqn{C_{i} = Concentration 1}{Ci = Concentration 1} \cr
#' \eqn{C_{i+1} = Concentration 2}{Ci+1 = Concentration 2} \cr
#' \eqn{T_{i} = Time 1}{Ti = Time 1} \cr
#' \eqn{T_{i+1} = Time 2}{Ti+1 = Time 2} \cr
#' \eqn{ln = Natural Logarithm} \cr \cr
#' \strong{Methods:} You can use the following methods to calculate AUC: \cr
#' \enumerate{
#'  \item \strong{Linear-Log Trapazoidal Rule}(default method): The linear method is used up to Tmax (the
#'  first occurrence of Cmax) and the log trapezoidal method is used for the remainder of the profile. If
#'  Ci or Ci+1 is 0 then the linear trapezoidal rule is used.
#'  \item \strong{Linear Trapazoidal Rule}: The linear method is used for the entire profile.
#'  \item \strong{Log Trapazoidal Rule}: The log trapezoidal method is used for the entire profile. If
#'  Ci or Ci+1 is 0 then the linear trapezoidal rule is used.
#'  \item \strong{Linear Up - Log Down Trapazoidal Rule}: Linear trapezoidal while the concentrations
#'  are increasing and log trapezoidal while the concentration are decreasing, the assessment is made on
#'  a step basis for each portion of the profile i.e. t1 to t2. If Ci or Ci+1 is 0 then the linear
#'  trapezoidal rule is used.
#' }
#'
#' @section Note:
#' The inputs 'exflag' and 't_max' are optional. If 't_max' input is not provided then it will generate the TMAXi using the concentration and time data provided. \cr \cr
#' \strong{tmax}: Refer to \code{\link{tmax}} for more details
#'
#' @param conc The concentration data (given in a vector form)
#' @param time The time data (given in a vector form)
#' @param method The method that will be used to calculate AUC (use either 1, 2, 3, or 4)\cr
#' \enumerate{
#' \item Linear-Log Trapezoidal Rule (default)
#' \item Linear Trapezoidal Rule
#' \item Log Trapezoidal Rule
#' \item Linear Up - Log Down Trapezoidal Rule
#' }
#' Note: check 'Methods' section below for more details \cr
#' @param exflag The exclude flag data (given in a numeric vector)
#' @param t_max The first time at which CMAXi is observed within the dosing interval (numeric value)
#'
#' @section Returns:
#' \strong{Value} \cr
#' \itemize{
#'  \item AUC: area under the curve
#' }
#'
#' @examples
#' ##########
#' ## Data ##
#' #############################################
#' ##  SID  ##  TIME  ##   CONC   ##  EXFLAG  ##
#' #############################################
#' ##   30  ##    0   ##   2.89   ##    0     ##
#' ##   30  ##    1   ##   2.49   ##    1     ##
#' ##   30  ##    2   ##   2.47   ##    0     ##
#' ##   30  ##    3   ##   2.38   ##    0     ##
#' ##   30  ##    4   ##   2.32   ##    0     ##
#' ##   30  ##    5   ##   2.28   ##    1     ##
#' ##   30  ##    6   ##   0      ##    1     ##
#' #############################################
#'
#' #Data mentioned will be used for the following example
#'
#' #auc_all()
#' #Error in auc_all: 'conc' and 'time' vectors are NULL
#'
#' conc_vector <- c(2.89, 2.49, 2.47, 2.38, 2.32, 2.28, 0)
#' time_vector <- c(0, 1, 2, 3, 4, 5, 6)
#' exflag_vector <- c(0, 1, 0, 0, 0, 1, 1)
#'
#' #auc_all(conc = conc_vector, time = time_vector, method = NA)
#' #Error in auc_all: the value provided for 'method' is not correct
#'
#' auc_all(conc = conc_vector, time = time_vector, method = 2)
#' #13.385
#'
#' auc_all(conc = conc_vector, time = time_vector, method = 1)
#' #13.37956
#'
#' auc_all(conc = conc_vector, time = time_vector, method = 1, exflag = exflag_vector)
#' #10.12361
#'
#' auc_all(conc = conc_vector, time = time_vector, method = 1, t_max = 2)
#' #13.38454
#'
#' ############
#' ## Data 2 ##
#' #############################################
#' ##  SID  ##  TIME  ##   CONC   ##  EXFLAG  ##
#' #############################################
#' ##   31  ##    0   ##      0   ##    0     ##
#' ##   31  ##    1   ##      0   ##    0     ##
#' ##   31  ##    2   ##      0   ##    0     ##
#' #############################################
#'
#' #Data mentioned will be used for the following example
#'
#' conc_vector <- c(0, 0, 0)
#' time_vector <- c(0, 1, 2)
#' exflag_vector <- c(0, 0, 0)
#'
#' auc_all(conc = conc_vector, time = time_vector, method = 1)
#' #0
#'
#' ############
#' ## Data 3 ##
#' #############################################
#' ##  SID  ##  TIME  ##   CONC   ##  EXFLAG  ##
#' #############################################
#' ##   32  ##    0   ##   1.19   ##    0     ##
#' ##   32  ##    1   ##   1.23   ##    1     ##
#' ##   32  ##    2   ##   1.34   ##    1     ##
#' #############################################
#'
#' #Data mentioned will be used for the following example
#'
#' conc_vector <- c(1.19, 1.23, 1.34)
#' time_vector <- c(0, 1, 2)
#' exflag_vector <- c(0, 1, 1)
#'
#' auc_all(conc = conc_vector, time = time_vector)
#' #2.495
#'
#' auc_all(conc = conc_vector, time = time_vector, exflag = exflag_vector)
#' #NA
#'
#' @author
#' \itemize{
#'  \item \strong{Rudraya Technical Team}
#'  \item website: \url{www.rudraya.com}
#'  \item email: \url{support@rudraya.com}
#' }
#' @export
auc_all <- function(conc = NULL, time = NULL, method = 1, exflag = NULL, t_max = NULL){
  if(is.null(conc) && is.null(time)){
    stop("Error in auc_all: 'conc' and 'time' vectors are NULL")
  } else if(is.null(conc)) {
    stop("Error in auc_all: 'conc' vector is NULL")
  } else if(is.null(time)) {
    stop("Error in auc_all: 'time' vectors is NULL")
  } else if(all(is.na(time))) { # 2019-09-13/TGT/
      return(NA)
  } else if(all(is.na(conc))) { # 2019-09-13/TGT/
      return(NA)
  }

  if(!(is.numeric(conc) && is.vector(conc)) ){
    stop("Error in auc_all: 'conc' is not a numeric vector")
  }
  if(!(is.numeric(time) && is.vector(time)) ){
    stop("Error in auc_all: 'time' is not a numeric vector")
  }
  if(length(time) != length(conc)){
    stop("Error in auc_all: length of 'time' and 'conc' vectors are not equal")
  }
  if((method != 1 && method != 2 && method != 3 && method != 4) || (is.null(method) || is.na(method))){
    stop("Error in auc_all: the value provided for 'method' is not correct")
  }
  if(sum(conc, na.rm = T) == 0){
    return(0)
  }

  if(method == 1){
    return(auc_lin_log(conc = conc, time = time, exflag = exflag, t_max = t_max))
  } else if(method == 2){
    return(auc_lin(conc = conc, time = time, exflag = exflag))
  } else if(method == 3){
    return(auc_log(conc = conc, time = time, exflag = exflag))
  } else if(method == 4){
    return(auc_lin_up_log_down(conc = conc, time = time, exflag = exflag))
  }
}
