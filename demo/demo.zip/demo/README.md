
# Table of Contents

-   [Dependencies for installation](#org9fc3a39)
    -   [devtools: Tools to Make Developing R Packages Easier](#org989a49d)
    -   [curl: A Modern and Flexible Web Client for R](#org227010e)
-   [Download Testcase scripts and data](#orgdaf6319)
-   [Open R or RStudio](#orgd145afe)
-   [Set your default folder in the R session](#org2a01759)
-   [Execute the installation script  openNCA Computation Engine package library](#orge2f14e2)

These instructions provide brief installation and testcase execution
guidance.


<a id="org9fc3a39"></a>

# Dependencies for installation


<a id="org989a49d"></a>

## [devtools: Tools to Make Developing R Packages Easier](https://CRAN.R-project.org/package=devtools)


<a id="org227010e"></a>

## [curl: A Modern and Flexible Web Client for R](https://CRAN.R-project.org/package=curl)


<a id="orgdaf6319"></a>

# Download Testcase scripts and data

<https://github.com/tensfeldt/openNCA/blob/master/demo/demo.zip>\* Demonstration Installation


<a id="orgd145afe"></a>

# Open R or RStudio

openNCA Computation Engine v3.0 (commit c3d3f48) has been qualified with R-3.5.1.
So consider R-3.5.1 as a minimum installation requirement.


<a id="org2a01759"></a>

# Set your default folder in the R session

This should be the folder **above** the "demo" folder that you downloaded


<a id="orge2f14e2"></a>

# Execute the installation script  openNCA Computation Engine package library

Load ../demo/install/openNCA<sub>commit</sub><sub>installation.R</sub> and
execute all of the lines.

Alternatively, source the file. 
For example, if you've downloaded demo.zip and unzipped to your Downloads folder:

    home <- Sys.getenv("HOMEPATH")
    setwd(file.path(home, "Downloads"))
    getwd()
    unzip("demo.zip")
    list.files("./demo")
    source("./demo/install/openNCA_commit_installation.R")

